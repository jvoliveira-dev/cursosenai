n = 1

while n <= 100:
    
    if n % 2 == 0:
        print(n)
        
    n += 1
